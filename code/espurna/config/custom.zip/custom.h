// ------------------------------------------------------------------------------
// Example file for custom.h
// Either copy and paste this file then rename removing the .example or create your
// own file: 'custom.h'
// This file allows users to create their own configurations.
// See 'code/espurna/config/general.h' for default settings.
//
// See: https://github.com/xoseperez/espurna/wiki/Software-features#enabling-features
// and 'code/platformio_override.ini.example' for more details.
// ------------------------------------------------------------------------------

//LOLIN with AnalogMux support
#if defined(NODEMCU_LOLIN_AM)

    // Info
    #define MANUFACTURER        "NODEMCU"
    #define DEVICE              "LOLIN_AM"

    // Buttons
    #define BUTTON1_PIN         0
    #define BUTTON1_CONFIG      BUTTON_PUSHBUTTON | BUTTON_DEFAULT_HIGH
    #define BUTTON1_RELAY       1

    // Hidden button will enter AP mode if dblclick and reset the device when long-long-clicked
    #define RELAY1_PIN          12
    #define RELAY1_TYPE         RELAY_TYPE_NORMAL

    // Light
    #define LED1_PIN            2
    #define LED1_PIN_INVERSE    1
	
	//AnalogMux and NTCMux
	#define SENSOR_SUPPORT     	1
	#define AnalogMux_SUPPORT 	1
	#define NTCMuxSensor_SUPPORT 1
	
#elif defined(NODEMCU_LOLIN_MAX30100)

   // Info
    #define MANUFACTURER        "NODEMCU"
    #define DEVICE              "LOLIN_MAX30100"

    // Buttons
    #define BUTTON1_PIN         0
    #define BUTTON1_CONFIG      BUTTON_PUSHBUTTON | BUTTON_DEFAULT_HIGH
    #define BUTTON1_RELAY       1

    // Hidden button will enter AP mode if dblclick and reset the device when long-long-clicked
    #define RELAY1_PIN          12
    #define RELAY1_TYPE         RELAY_TYPE_NORMAL

    // Light
    #define LED1_PIN            2
    #define LED1_PIN_INVERSE    1
	
	//AnalogMux and NTCMux
	#define SENSOR_SUPPORT     	1
    #define MAX30100_SUPPORT 1

#elif defined(NODEMCU_LOLIN_AI_RS)
    // Info
    #define MANUFACTURER        "NODEMCU"
    #define DEVICE              "LOLIN_AI_RS"

    // Buttons
    #define BUTTON1_PIN         0
    #define BUTTON1_CONFIG      BUTTON_PUSHBUTTON | BUTTON_DEFAULT_HIGH
    #define BUTTON1_RELAY       1

    // Hidden button will enter AP mode if dblclick and reset the device when long-long-clicked
    #define RELAY1_PIN          12
    #define RELAY1_TYPE         RELAY_TYPE_NORMAL

    // Light
    #define LED1_PIN            2
    #define LED1_PIN_INVERSE    1
	
	//AnalogMux and NTCMux
	#define SENSOR_SUPPORT     	1
    #define I2C_SUPPORT 1
	#define ANALOG_INPUTS_SUPPORT 	1
	#define RAW_ANALOG_SENSOR_SUPPORT 1

#elif defined(NODEMCU_LOLIN_AI_RN)
    // Info
    #define MANUFACTURER        "NODEMCU"
    #define DEVICE              "LOLIN_AI_RN"

    // Buttons
    #define BUTTON1_PIN         0
    #define BUTTON1_CONFIG      BUTTON_PUSHBUTTON | BUTTON_DEFAULT_HIGH
    #define BUTTON1_RELAY       1

    // Hidden button will enter AP mode if dblclick and reset the device when long-long-clicked
    #define RELAY1_PIN          12
    #define RELAY1_TYPE         RELAY_TYPE_NORMAL

    // Light
    #define LED1_PIN            2
    #define LED1_PIN_INVERSE    1
	
	//AnalogInputs, Raw Sensors and NTCMux sensors
	#define SENSOR_SUPPORT     	1
    #define I2C_SUPPORT 1
	#define ANALOG_INPUTS_SUPPORT 	1
	#define NTC_MUX_SENSOR_SUPPORT  1
	#define RAW_ANALOG_SENSOR_SUPPORT 1


#endif
